package base_class;

public class parent 
{
	public String tc_id;
	public String flag;
	public String keyword;
	public String xpath;
	public String test_data;
	public int steps;

}
