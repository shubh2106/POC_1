package utility;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import base_class.parent;

public class read_write extends parent
{

	public void read(int x, String a)
	{
		if(a.contains("TC_SELECTION"))
		{
			try
			{
				File f=new File("C:\\Users\\shubham.jaiswal\\Downloads\\Tc_condition.xlsx");
			
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("TC_SELECTION");
			XSSFRow row=sh.getRow(x);
			
			XSSFCell cell1=row.getCell(0);
			XSSFCell cell2=row.getCell(1);
			XSSFCell cell3=row.getCell(2);
			
			 tc_id=cell1.getStringCellValue();
			 flag=cell2.getStringCellValue();
			steps=(int) cell3.getNumericCellValue();
			
			}
			catch(Exception e)
			{
				
			}
		}
			
	
		else
		{
		
		try {
			 File f=new File("C:\\Users\\shubham.jaiswal\\Downloads\\Tc_condition.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("KEYWORD");
				XSSFRow row=sh.getRow(x);
				
				XSSFCell cell2=row.getCell(2);
				XSSFCell cell3=row.getCell(3);
				XSSFCell cell4=row.getCell(4);
				
				 keyword=cell2.getStringCellValue();
				 xpath=cell3.getStringCellValue();
				 test_data=cell4.getStringCellValue();
		 	}
		 catch(Exception e)
		 {
			 
		 }
		}
	}
	public void write(int x,String a,String b)
	{
		
		if(a.contains("TC_SELECTION"))
		try
		{
			File f=new File("C:\\Users\\shubham.jaiswal\\Downloads\\Tc_condition.xlsx");
		
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("TC_SELECTION");
		XSSFRow row=sh.getRow(x);
		XSSFCell cell4=row.getCell(3);
		cell4.setCellValue(b);
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		}
		catch(Exception e)
		{
			
		}
		else
			try
		{
			File f=new File("C:\\Users\\shubham.jaiswal\\Downloads\\Tc_condition.xlsx");
		
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("KEYWORD");
		XSSFRow row=sh.getRow(x);
		XSSFCell cell6=row.getCell(5);
		cell6.setCellValue(b);
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		}
		catch(Exception e)
		{
			
		}
			
		
		
	}
	public static String read_ids(int i) throws IOException 
	{
		String id;
		File f=new File("C:\\Users\\shubham.jaiswal\\Downloads\\Tc_condition.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("KEYWORD");
		XSSFRow rw=sh.getRow(i);
		id=rw.getCell(0).getStringCellValue();
		//System.out.println(id);

		return id;

	}  

}
